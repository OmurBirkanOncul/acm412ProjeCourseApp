from django import forms
from courses.models import Course
# class CourseCreateForm(forms.Form):
#     title = forms.CharField(
#         label="kurs başligi",
#         error_messages={"required":"kurs basligi girmelisiniz."},
#         widget=forms.TextInput(attrs={"class":"form-control"})
#         )


#     description = forms.CharField(
#         widget=forms.Textarea(attrs={"class":"form-control"})
#         )
    

#     imageUrl = forms.CharField(
#         widget=forms.TextInput(attrs={"class":"form-control"})
#         )
    
class CourseForm(forms.ModelForm):
    class Meta:
        model=Course
        fields=('title','description','image','categories','isActive','isHome',)
        widgets= {
            "title":forms.TextInput(attrs={"class":"form-control"}),
            "description":forms.Textarea(attrs={"class":"form-control"}),
            "categories":forms.SelectMultiple(attrs={"class":"form-control"}),
        }
        error_messages={
            "title":{
                "required":"kurs basligi girmelisiniz.",
                "max_length":"maximum 50 karakter girmelisiniz."
                },
            "description":{
                "required":"kurs açiklamasini girmelisiniz.",
            }
        }

# class CourseCreateForm(forms.ModelForm):
#     class Meta:
#         model=Course
#         fields=('title','description','imageUrl','categories','isActive','isHome',)
#         widgets= {
#             "title":forms.TextInput(attrs={"class":"form-control"}),
#             "description":forms.Textarea(attrs={"class":"form-control"}),
#             "imageUrl":forms.TextInput(attrs={"class":"form-control"}),
#             "categories":forms.SelectMultiple(attrs={"class":"form-control"}),
#         }
#         error_messages={
#             "title":{
#                 "required":"kurs basligi girmelisiniz.",
#                 "max_length":"maximum 50 karakter girmelisiniz."
#                 },
#             "description":{
#                 "required":"kurs açiklamasini girmelisiniz.",
#             }
#         }

class UploadForm(forms.Form):
    image=forms.ImageField()